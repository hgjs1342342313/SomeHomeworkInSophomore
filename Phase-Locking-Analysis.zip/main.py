import phase
import math
import numpy as np
import matplotlib
import matplotlib.pyplot as plt



plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文标签
plt.rcParams['axes.unicode_minus'] = False
fs = 150  # 采样频率
L = 10  # 噪声强度
circlr_num = 5

t = np.linspace(0, circlr_num * 2 * math.pi, circlr_num * fs)


# 产生信号
s1, s2 = phase.Signal_Generate(t, L)
t = len(s1)

# print(s1)
# print(s2)
# 相同步相干指数分析

r1 = phase.phase_analysis(s1, s2)
# PLI
r2 = phase.PLI_analysis(s1, s2)
# wPLI
r3 = phase.wPLI_analysis(s1, s2)

# 取最终值作为结果
end = len(s1)-1
for i in range(0, end):

    result1 = str(r1)
    result2 = str(r2)
    result3 = str(r3)
# 绘图L = 0
plt.subplot(4, 1, 1)
plt.plot(s1)

plt.plot(s2)
plt.title('信号   fs: 10Hz  噪声水平:  10')
# axis([1, 120, -1.2, 1.2])
plt.xlim([1, 1200])
plt.xticks((0, 24, 48, 72, 96, 120))
# plt.xticklabels(0, 0.02, 0.04, 0.06, 0.08, 0.1)
plt.xlabel('Time/Sec')
# plt.fontsize(12)

    # 绘图
    # 相同步相干

plt.subplot(4, 1, 2)
plt.plot(r1)
plt.xlim([1, 1200])
plt.ylim([0, 1])
plt.title('相同步相干指数 R=%f' % r1[-1])

    # set(gca, 'xtick', [0, 240, 480, 720, 960, 1200], 'xticklabel', [0 0.2 0.4 0.6 0.8 1]);
    # xlabel('Time/Sec')
    # set(gca, 'fontsize', 12)
    # % % 绘图PLI
plt.subplot(4, 1, 3)
plt.plot(r2)
plt.xlim([1, 1200])
plt.ylim([0, 1])
plt.title('PLI = %f' % r2[-1])
plt.xlabel('Time/Sec')
    # set(gca, 'xtick', [0, 240, 480, 720, 960, 1200], 'xticklabel', [0 0.2 0.4 0.6 0.8 1]);

    # set(gca, 'fontsize', 12)
    # 绘图wPLI
plt.subplot(4, 1, 4)

plt.plot(r3)
plt.xlim([1, 1200])
plt.ylim([0, 1])
plt.title('wPLI L=%f ' % r3[-1])
plt.show()
    # set(gca, 'xtick', [0, 240, 480, 720, 960, 1200], 'xticklabel', [0 0.2 0.4 0.6 0.8 1]);
    # xlabel('Time/Sec')
    # set(gca, 'fontsize', 12);
