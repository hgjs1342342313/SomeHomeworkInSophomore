import scipy.signal as signal
from scipy.fftpack import fft
import numpy as np
import math
#对s1,s2进行相同指数分析

# 希尔伯特变换
def Hilbert(s):
    s_hilbert = signal.hilbert(s)
    s_real = np.real(s_hilbert)  # 取实部
    s_imag = np.imag(s_hilbert)  # 取虚部
    phase = np.arctan2(s_imag, s_real)  # 反正切
    return phase

# 将相位值调整到正负π之间


def adjust_phase(phase1, phase2):
    phase12 = phase1 - phase2   # 瞬时相位差
    # phase12 = np.array(phase12)
    # print(phase12)
    L = len(phase12)
    for m in range(1, 4):
        for i in range(1, L):
            if phase12[i] >= math.pi:
                phase12[i] = phase12[i] - 2 * math.pi
            elif phase12[i] < -math.pi:
                phase12[i] = phase12[i] + 2 * math.pi
    return phase12


# 相同步相干指数
def phase_analysis(s1, s2):
    phase1 = Hilbert(s1)
    phase2 = Hilbert(s2)
    phase12 = adjust_phase(phase1, phase2)
    tnum = len(s1)
    r = []
    rmatrix = []
    # print(phase12)
    for i in range(0, tnum-1):
        for j in range(0, i):
            rmatrix.append(complex(0, phase12[j]))
        x = np.exp(rmatrix)
        r.append(abs(np.mean(x)))

    return r


# 相滞指数
def PLI_analysis(s1, s2):
    phase1 = Hilbert(s1)
    phase2 = Hilbert(s2)
    phase12 = adjust_phase(phase1, phase2)
    tnum = len(s1)
    r = [0 for t in range(0, tnum-1)]
    x = np.sign(phase12)
    y = 0
    for i in range(0, tnum-1):
        for j in range(0, i):
            y = y + x[j]
        y = y / (i+1)
        r[i] = abs(y)
    return r


# 去偏平方加权相滞后指数
def wPLI_analysis(s1, s2):
    tnum = len(s1)
    r1 = [0 for t in range(0, tnum-1)]

    for i in range(31, tnum-1):
        tmp1 = []
        tmp2 = []
        for j in range(0, i):
            tmp1.append(s1[j])
            tmp2.append(s2[j])

        # s1 FFT
        SpectrumAmp_1 = []
        SpectrumAmp_2 = []
        lengen = len(tmp1)
        SpectrumAmp1 = fft(tmp1) / (lengen / 2)
        for i in range(0, int(lengen/2)-1):
            SpectrumAmp_1.append(SpectrumAmp1[i])
            # s2 FFT
        lengen = len(tmp2)
        SpectrumAmp2 = fft(tmp2) / (lengen / 2)
        for i in range(0, int(lengen/2)-1):
            SpectrumAmp_2.append(SpectrumAmp2)
            # 正交谱计算
        f, c = signal.csd(SpectrumAmp_1, SpectrumAmp_2)
        c_imag = [0 for t in range(0, int(lengen/2)-1)]
        for i in range(0, int(lengen/2)-1):
            c_imag[i] = np.imag(c[i])
        # wPLI指数
        tmp3 = np.abs(np.sum(c_imag))

        tmp4 = np.sum(np.abs(c_imag))

        r1[i] = tmp3 / tmp4

    return r1


def Signal_Generate(t, l):
    tnum = len(t)
    signal_21 = np.sin(2 * math.pi * 10 * t)
    noise = l * 2 * (np.random.rand(tnum, 1) - 0.5)
    signal_22 = np.sin(2 * math.pi * 10 * t + math.pi / 12)
    # print(signal_22)
    # print(noise)
    for i in range(len(noise)):
        # 迭代输出列

         signal_22[i] = signal_22[i] + noise[i]
    # signal_22 = np.sin(2 * math.pi * 10 * t + math.pi / 12) + noise

    return signal_21, signal_22




